let express = require("express");
let app = express();


let moment = require('moment');



app.get("/", function(req, res) {
	let date = new Date();
	let time = date.getHours()+4 + ":" + date.getMinutes() + ":" + date.getSeconds();
  res.send(time);
});
app.listen(process.env.PORT || 8080);
console.log('listening...');


